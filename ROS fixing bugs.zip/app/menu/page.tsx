// app/menu/page.tsx
'use client';

import Header from '../../components/Header';
import { useState, Suspense, useEffect, useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '../../lib/supabaseClient';

function MenuContent() {
  const searchParams = useSearchParams();
  const categoryFromUrl = searchParams?.get('category') || '';
  
  const [selectedCategory, setSelectedCategory] = useState(String(categoryFromUrl || 'all'));
  const [searchTerm, setSearchTerm] = useState('');
  const [cartItems, setCartItems] = useState<{[key: number]: number}>({});
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);



  const [modalOpen, setModalOpen] = useState(false);
  const [modalCategoryId, setModalCategoryId] = useState<string | number | null>(null);








  // ---------- Skeletons ----------
  const SkeletonCategory = () => (
    <div className="flex flex-col items-center">
      <div className="w-16 h-16 bg-gray-200 rounded-full mb-3" />
      <div className="w-24 h-4 bg-gray-200 rounded-full" />








    </div>
  );

  const SkeletonCard = () => (
    <div className="bg-white rounded-2xl p-4 shadow-sm">
      <div className="aspect-video bg-gray-200 rounded-md mb-4" />
      <div className="h-5 bg-gray-200 rounded w-3/4 mb-2" />
      <div className="h-4 bg-gray-200 rounded w-1/2 mb-3" />
      <div className="flex justify-between items-center">
        <div className="h-8 w-20 bg-gray-200 rounded-full" />
        <div className="h-8 w-20 bg-gray-200 rounded-full" />
      </div>
    </div>
  );

  // ---------- Category icons ----------
  const BUCKETNAME = 'menu-images';

  const categoryIconMap = useMemo(() => {
    const map: Record<string, string | null> = {};
    if (!categories || categories.length === 0) return map;

    categories.forEach((cat: any) => {
      const raw = (cat.icon ?? cat.icon_url ?? '') as string;
      if (!raw) {
        map[cat.id] = null;
        return;
      }
      if (raw.startsWith('data:') || raw.startsWith('http://') || raw.startsWith('https://')) {
        map[cat.id] = raw;
        return;
      }
      let path = raw;
      if (path.startsWith(`${BUCKETNAME}/`)) path = path.replace(`${BUCKETNAME}/`, '');
      if (path.startsWith('/')) path = path.slice(1);
      try {
        const { data } = supabase.storage.from(BUCKETNAME).getPublicUrl(path);
        map[cat.id] = data?.publicUrl ?? null;
      } catch (err) {
        console.warn('getPublicUrl error for', path, err);
        map[cat.id] = null;
      }
    });
    return map;
  }, [categories]);

  // ---------- Effects ----------
// restore cart + load menu data (run once on mount)
useEffect(() => {
  try {
    const savedCart = JSON.parse(localStorage.getItem('cartItems') || '{}');
    setCartItems(savedCart);
  } catch {
    setCartItems({});
  }

  // call the async loader
  loadMenuData();
}, []);

// ESC key closes modal (only active while modalOpen)
useEffect(() => {
  if (!modalOpen) return;

  const onKey = (e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      setModalOpen(false);
      setModalCategoryId(null);
    }
  };
  window.addEventListener('keydown', onKey);
  return () => window.removeEventListener('keydown', onKey);
}, [modalOpen]);








  const loadMenuData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/admin-menu-service`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({ action: 'getMenuData' })
      });

      const data = await response.json();


if (data.success) {
  const allCategory = { id: 'all', name: 'All Items' };

  // items array (safe)
  const items = Array.isArray(data.menuItems) ? data.menuItems : [];

  // Build categories (keep counts)
  const categoriesWithCounts = [(allCategory), ...(data.categories || []).map((cat: any) => ({
    ...cat,
    count: items.filter((it: any) => String(it.category_id) === String(cat.id)).length
  }))];
  setCategories(categoriesWithCounts);

  // --- robust parsing & flag derivation ---
  const parseTimeSafe = (v: any): number => {
    if (!v && v !== 0) return 0;
    if (typeof v === 'number') return v;
    if (typeof v === 'string') {
      const asNum = Number(v);
      if (!Number.isNaN(asNum) && String(v).trim().length >= 10) return asNum;
      const asDate = Date.parse(v);
      if (!Number.isNaN(asDate)) return asDate;
      return 0;
    }
    try {
      const cast = new Date(v as any).getTime();
      return Number.isNaN(cast) ? 0 : cast;
    } catch {
      return 0;
    }
  };

  const deriveFlagsForItem = (item: any, now = Date.now(), newThresholdMs = 7 * 24 * 60 * 60 * 1000) => {
    const createdRaw = item.created_at ?? null;
    const updatedRaw = item.updated_at ?? null;

    const created = parseTimeSafe(createdRaw);
    const updated = parseTimeSafe(updatedRaw);

    const isEdited = typeof item.isEdited === 'boolean'
      ? !!item.isEdited
      : (updated > 0 && created > 0 && updated !== created);

    const isNew = typeof item.isNew === 'boolean'
      ? !!item.isNew
      : (created > 0 && (now - created) <= newThresholdMs);

    const lastChanged = Math.max(created || 0, updated || 0);

    return { created, updated, isEdited, isNew, lastChanged };
  };

  const now = Date.now();
  const NEW_THRESHOLD_MS = 7 * 24 * 60 * 60 * 1000; // 7 days; adjust if you want

  const enriched = items.map((it: any) => {
    const meta = deriveFlagsForItem(it, now, NEW_THRESHOLD_MS);
    return { ...it, __meta: meta };
  });

  // --- sort: priority new/edited first, then lastChanged desc (newest first) ---
  enriched.sort((a: any, b: any) => {
    const A = a.__meta ?? {};
    const B = b.__meta ?? {};

    const aPriority = (A.isNew || A.isEdited) ? 1 : 0;
    const bPriority = (B.isNew || B.isEdited) ? 1 : 0;
    if (aPriority !== bPriority) return bPriority - aPriority; // higher priority first

    const aLast = Number(A.lastChanged || 0);
    const bLast = Number(B.lastChanged || 0);
    if (bLast !== aLast) return bLast - aLast;

    const aCreated = Number(A.created || 0);
    const bCreated = Number(B.created || 0);
    if (bCreated !== aCreated) return bCreated - aCreated;

    // final fallback: numeric id descending (newer id first) or string fallback
    const aIdNum = Number(a.id);
    const bIdNum = Number(b.id);
    if (!Number.isNaN(aIdNum) && !Number.isNaN(bIdNum)) {
      return bIdNum - aIdNum;
    }
    return String(b.id || '').localeCompare(String(a.id || ''));
  });

  // set state & cache sorted enriched items
  setMenuItems(enriched.map((i: any) => i));
  try {
    localStorage.setItem('menuItems', JSON.stringify(enriched));
  } catch (e) {
    console.warn('Unable to cache menu items', e);
  }
}



    } catch (error) {
      console.error('Error loading menu data:', error);
    }
    setLoading(false);
  };

  // ---------- Helpers ----------
const filteredItems = menuItems.filter(item => {
  const itemCatId = String(item.category_id ?? item.category?.id ?? '');
  const matchesCategory =
    selectedCategory === 'all' ||
    itemCatId === String(selectedCategory) ||
    (item.category?.slug && item.category.slug === selectedCategory);

  const matchesSearch =
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.description || '').toLowerCase().includes(searchTerm.toLowerCase());

  return matchesCategory && matchesSearch;
});


  const modalCategoryCount = (() => {
    if (!modalCategoryId) return 0;
    if (String(modalCategoryId) === 'all') return menuItems.length;
    return menuItems.filter(i =>
      String(i.category_id ?? i.category?.id ?? '') === String(modalCategoryId)
    ).length;
  })();




  const addToCart = (itemId: number) => {
    const newCart = { ...cartItems, [itemId]: (cartItems[itemId] || 0) + 1 };
    setCartItems(newCart);
    localStorage.setItem('cartItems', JSON.stringify(newCart));
  };

  const updateQuantity = (itemId: number, quantity: number) => {
    if (quantity <= 0) {
      const { [itemId]: _, ...newCart } = cartItems;
      setCartItems(newCart);
      localStorage.setItem('cartItems', JSON.stringify(newCart));
    } else {
      const newCart = { ...cartItems, [itemId]: quantity };
      setCartItems(newCart);
      localStorage.setItem('cartItems', JSON.stringify(newCart));
    }
  };

  const getTotalItems = () =>
    Object.values(cartItems).reduce((sum, qty) => sum + qty, 0);

  const getTotalPrice = () =>
    Object.entries(cartItems).reduce((total, [itemId, qty]) => {
      const item = menuItems.find(i => i.id === parseInt(itemId));
      return total + (item ? item.price * qty : 0);
    }, 0);

  const getIngredientsList = (ingredients: any) => {
    if (!ingredients) return [];
    if (Array.isArray(ingredients)) return ingredients;
    if (typeof ingredients === 'string') return ingredients.split(', ');
    return [];
  };

  // ---------- Render ----------
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Menu Header */}
<section className="bg-gradient-to-b from-white to-gray-50 py-12">
  <div className="container mx-auto px-4">
    {/* Heading */}
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Our Menu</h2>


    {/* Search bar */}
    <div className="max-w-2xl mx-auto mb-8">
      <div className="relative">
        <label htmlFor="menu-search" className="sr-only">Search menu items</label>

        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <i className="ri-search-line text-gray-400 text-lg" />
        </div>

        <input
          id="menu-search"
          type="search"
          placeholder="Search menu items..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-12 py-3 border border-gray-200 rounded-full shadow-sm bg-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-300 transition"
        />

        {searchTerm && (
          <button
            type="button"
            onClick={() => setSearchTerm('')}
            aria-label="Clear search"
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
          >
            <i className="ri-close-line text-lg" />
          </button>
        )}
      </div>
    </div>

    {/* Category grid */}
    {loading ? (
      <div className="grid grid-cols-3 md:grid-cols-6 gap-6 animate-pulse">
        <SkeletonCategory />
        <div className="hidden md:block"><SkeletonCategory /></div>
        <div className="hidden md:block"><SkeletonCategory /></div>
        <div className="hidden lg:block"><SkeletonCategory /></div>
        <div className="hidden lg:block"><SkeletonCategory /></div>
        <div className="hidden lg:block"><SkeletonCategory /></div>
      </div>
    ) : categories.length === 0 ? (
      <div className="text-center py-8">
        <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
          <i className="ri-folder-line text-2xl text-gray-400" />
        </div>
        <h3 className="text-xl font-semibold text-gray-600 mb-2">No Categories Available</h3>
        <p className="text-gray-500">The owner needs to add categories and menu items</p>
      </div>
    ) : (
      // compact responsive grid for consistent layout
      <div className="max-w-5xl mx-auto mb-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {[...categories]
            .sort((a: any, b: any) => {
              // keep "all" first
              if (a.id === 'all') return -1;
              if (b.id === 'all') return 1;
              return String(a.name).localeCompare(String(b.name));
            })
            .map((category: any) => {
              const src = categoryIconMap?.[category.id] ?? null;
              const isActive = selectedCategory === category.id;
              const count =
                category.id === 'all'
                  ? menuItems.length
                  : category.count ??
                    menuItems.filter((it: any) => String(it.category_id) === String(category.id)).length;

              return (
                <button
                  key={category.id}
                  onClick={() => {
  setSelectedCategory(category.id);
  setModalCategoryId(category.id);
  setModalOpen(true);
}}

                  aria-pressed={isActive}
                  className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-left transition transform ${
                    isActive
                      ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-md'
                      : 'bg-white border border-gray-100 text-gray-800 hover:shadow-sm hover:-translate-y-0.5'
                  } focus:outline-none focus:ring-2 focus:ring-orange-300`}
                  type="button"
                >
                  {/* avatar */}
                  <div className={`flex-shrink-0 w-10 h-10 rounded-full overflow-hidden ${isActive ? 'ring-2 ring-white' : ''}`}>
                    {src ? (
                      <img
                        src={src}
                        alt={category.name}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                      />
                    ) : (
                      <div className="w-full h-full bg-orange-50 flex items-center justify-center">
                        <i className={`ri-restaurant-line ${isActive ? 'text-white' : 'text-orange-600'} text-lg`} />
                      </div>
                    )}
                  </div>

                  {/* name + count */}
                  <div className="flex items-center justify-between w-full">
                    <span className={`truncate font-medium ${isActive ? 'text-white' : 'text-gray-800'}`}>
                      {category.name}
                    </span>

                    <span className={`ml-3 inline-flex items-center justify-center text-xs font-semibold px-2 py-0.5 rounded-full ${
                      isActive ? 'bg-white/25 text-white' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {count}
                    </span>



                    
                  </div>
                </button>
              );
            })}
        </div>
      </div>
    )}
  </div>
</section>

    {/* Menu Items */}
<section className="py-8">
  <div className="container mx-auto px-4">
    {loading ? (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="animate-pulse"><SkeletonCard /></div>
        <div className="animate-pulse"><SkeletonCard /></div>
        <div className="animate-pulse hidden lg:block"><SkeletonCard /></div>
        <div className="animate-pulse hidden lg:block"><SkeletonCard /></div>
        <div className="animate-pulse hidden lg:block"><SkeletonCard /></div>
      </div>
    ) : menuItems.length === 0 ? (
      <div className="text-center py-16">
        <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="ri-restaurant-line text-2xl text-gray-400"></i>
        </div>
        <h3 className="text-xl font-semibold text-gray-600 mb-2">No Menu Items Available</h3>
        <p className="text-gray-500 mb-6">The owner needs to add menu items to display here</p>
        <Link href="/" className="bg-orange-600 text-white px-6 py-3 rounded-full font-semibold hover:bg-orange-700 transition-colors cursor-pointer whitespace-nowrap">
          Back to Home
        </Link>
      </div>
    ) : filteredItems.length === 0 ? (
      <div className="text-center py-16">
        <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="ri-search-line text-2xl text-gray-400"></i>
        </div>
        <h3 className="text-xl font-semibold text-gray-600 mb-2">No items found</h3>
        <p className="text-gray-500">Try adjusting your search or filter criteria</p>
      </div>
    ) : (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" data-product-shop>
        {[...filteredItems]
          .sort((a: any, b: any) => {
            const an = (a?.name ?? '').toLowerCase();
            const bn = (b?.name ?? '').toLowerCase();
            if (an < bn) return -1;
            if (an > bn) return 1;
            return 0;
          })
          .map((item) => {
            const ingredientsList = getIngredientsList(item.ingredients);
            const meta = item.__meta || {};
            const isNew = !!meta.isNew;
            const isEdited = !!meta.isEdited;

            return (
              <div key={item.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                
                {/* Image block */}
                <div className="relative bg-gray-50">
                  <div className="aspect-[4/3] bg-gray-100 flex items-center justify-center p-4 overflow-hidden">
                    <img
                      src={item.image_url || 'https://via.placeholder.com/400x300?text=Menu+Item'}
                      alt={item.name}
                      className="max-w-full max-h-full object-contain rounded-md"
                      loading="lazy"
                      onError={(e) => { (e.currentTarget as HTMLImageElement).src = '/images/placeholder-food.png'; }}
                    />
                  </div>

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex gap-2 z-10">
                    {isNew && (
                      <span className="px-2 py-1 bg-green-600 text-white text-xs rounded-full font-semibold">NEW</span>
                    )}
                    {isEdited && (
                      <span className="px-2 py-1 bg-yellow-600 text-white text-xs rounded-full font-semibold">EDITED</span>
                    )}
                  </div>

                  {/* Veg pill */}
                  {item.is_vegetarian && (
                    <div className="absolute top-3 right-3 z-10">
                      <div className="w-7 h-7 bg-green-600 rounded-full flex items-center justify-center">
                        <div className="w-3 h-3 bg-white rounded-full" />
                      </div>
                    </div>
                  )}

                  {/* Out of stock overlay */}
                  {!item.is_available && (
                    <div className="absolute inset-0 flex items-center justify-center z-20">
                      <div className="w-full h-full bg-black bg-opacity-40 flex items-center justify-center">
                        <span className="text-white font-semibold text-lg">Out of Stock</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-gray-800">{item.name}</h3>
                    <span className="text-xl font-bold text-orange-600">₨{item.price}</span>
                  </div>
                  <p className="text-gray-600 mb-3">{item.description || 'Delicious traditional dish'}</p>

                  {ingredientsList.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-gray-700 mb-2">Ingredients:</h4>
                      <div className="flex flex-wrap gap-1">
                        {ingredientsList.map((ingredient: string, index: number) => (
                          <span key={index} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">{ingredient}</span>
                        ))}
                      </div>
                    </div>
                  )}

                  {cartItems[item.id] ? (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => updateQuantity(item.id, cartItems[item.id] - 1)}
                          className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 cursor-pointer"
                        >
                          <i className="ri-subtract-line"></i>
                        </button>
                        <span className="font-semibold text-lg">{cartItems[item.id]}</span>
                        <button
                          onClick={() => updateQuantity(item.id, cartItems[item.id] + 1)}
                          className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center hover:bg-orange-700 cursor-pointer"
                        >
                          <i className="ri-add-line"></i>
                        </button>
                      </div>
                      <span className="font-bold text-orange-600">
                        ₨{(item.price * cartItems[item.id]).toLocaleString()}
                      </span>
                    </div>
                  ) : (
                    <button
                      onClick={() => addToCart(item.id)}
                      disabled={!item.is_available}
                      className={`w-full py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                        item.is_available
                          ? 'bg-orange-600 text-white hover:bg-orange-700'
                          : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      }`}
                    >
                      {item.is_available ? 'Add to Cart' : 'Out of Stock'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
      </div>
    )}
  </div>
</section>

{/* Category Modal (fixed and clean) */}
{modalOpen && (
  <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
    {/* Backdrop */}
    <button
      onClick={() => { setModalOpen(false); setModalCategoryId(null); }}
      className="absolute inset-0 bg-black/50"
      aria-hidden="true"
    />

    {/* Panel: flex-column so footer can be outside the scrollable area */}
    <div
      className="relative w-full max-w-4xl sm:rounded-xl bg-white shadow-2xl overflow-hidden
                 sm:mx-4 sm:my-8 flex flex-col sm:max-h-[80vh] max-h-[90vh]"
      role="dialog"
      aria-modal="true"
    >
      {/* Header */}
      <div className="flex justify-between items-center px-4 py-3 border-b">
        <h3 className="font-semibold text-lg">
          {categories.find((c) => String(c.id) === String(modalCategoryId))?.name ?? 'Category'}
            <span className="inline-flex ml-3 items-center justify-center bg-orange-500 text-white font-semibold text-sm w-8 h-8 rounded-full shadow-sm">
              {modalCategoryCount}
            </span>


        </h3>





                <button
                  onClick={() => { setModalOpen(false); setModalCategoryId(null); }}
                  aria-label="Close"
                  className="p-2 rounded-md hover:bg-gray-100"
                >
                  <i className="ri-close-line text-2xl text-gray-600" />
                </button>
        </div>





      {/* Scrollable content */}
      <div className="overflow-auto p-4 sm:p-6 flex-1" style={{ minHeight: 0 }}>


{/* Replace the existing grid block with this: alphabetical order (case-insensitive) */}
<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
  {menuItems
    .filter((item) => {
      // keep existing filtering behavior:
      if (modalCategoryId === 'all' || modalCategoryId === null) return true;
      return String(item.category_id) === String(modalCategoryId);
    })
    // sort alphabetically by name (case-insensitive, locale-aware)
    .sort((a, b) => {
      const an = (a?.name ?? '').toString();
      const bn = (b?.name ?? '').toString();
      // use localeCompare for better language handling; 'base' sensitivity ignores accents/case
      return an.localeCompare(bn, undefined, { sensitivity: 'base', numeric: true });
    })
    .map((item) => (
      <div key={item.id} className="bg-white p-4 rounded-lg shadow-sm flex gap-4">
        <img
          src={item.image_url || '/images/placeholder-food.png'}
          alt={item.name}
          className="w-24 h-20 object-cover rounded"
          onError={(e) => { (e.currentTarget as HTMLImageElement).src = '/images/placeholder-food.png'; }}
        />
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h4 className="font-medium">{item.name}</h4>
            <span className="text-orange-600 font-semibold">₨{item.price}</span>
          </div>
          <p className="text-xs text-gray-500 mt-1 line-clamp-2">{item.description}</p>
          <div className="mt-3 flex items-center gap-3">
            <button
              onClick={() => addToCart(item.id)}
              className="px-3 py-1 bg-orange-600 text-white rounded text-sm"
            >
              Add
            </button>
          </div>
        </div>
      </div>
    ))}
</div>



      </div>

      {/* Footer - always visible (sticky) */}
      <div className="border-t px-4 py-4 bg-white">
        <div className="container mx-auto flex items-center justify-between max-w-4xl">
          <div className="text-sm">
            <span className="font-semibold text-gray-800">{getTotalItems()} items in cart</span>
            <span className="ml-4 font-bold text-orange-600 text-lg">₨{getTotalPrice().toLocaleString()}</span>
          </div>

          <Link
            href="/cart"
            onClick={() => { setModalOpen(false); setModalCategoryId(null); }}
            className="inline-flex items-center px-6 py-3 rounded-full bg-orange-600 text-white font-semibold hover:bg-orange-700 transition-colors"
          >
            View Cart
          </Link>
        </div>
      </div>
    </div>
  </div>
)}




      {/* Cart Summary */}
      {getTotalItems() > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4 z-40">
          <div className="container mx-auto flex justify-between items-center">
            <div>
              <span className="font-semibold text-gray-800">{getTotalItems()} items in cart</span>
              <span className="ml-4 font-bold text-orange-600 text-lg">₨{getTotalPrice().toLocaleString()}</span>
            </div>
            <Link href="/cart" className="bg-orange-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-orange-700 transition-colors cursor-pointer whitespace-nowrap">
              View Cart
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

export default function MenuPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-orange-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading menu...</p>
        </div>
      </div>
    }>
      <MenuContent />
    </Suspense>
  );
}
