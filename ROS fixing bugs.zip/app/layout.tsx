// app/layout.tsx
import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";

const pacifico = Pacifico({
  weight: "400",
  subsets: ["latin"],
  display: "swap",
  variable: "--font-pacifico",
});

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const SITE_URL = "https://newaribhattiandkathmandumomoghar.com";
const LOGO_PATH = "https://nweybjowqtrqpdxqfwkg.supabase.co/storage/v1/object/public/menu-images/Banner/Logo.png";
// and update the openGraph/twitter images to use this complete URL

export const metadata: Metadata = {
  title: "Newari Bhatti & Kathmandu Momo Ghar",
  description:
    "Authentic Newari dishes and momos in Kathmandu. Order online or visit Newari Bhatti & Kathmandu Momo Ghar.",
  metadataBase: new URL(SITE_URL),
  alternates: {
    canonical: SITE_URL,
  },
  openGraph: {
    title: "Newari Bhatti & Kathmandu Momo Ghar",
    description:
      "Authentic Newari dishes and momos in Kathmandu. Order online or visit our restaurant.",
    url: SITE_URL,
    images: [
      {
        url: `${SITE_URL}${LOGO_PATH}`,
        width: 1200,
        height: 630,
        alt: "Newari Bhatti & Kathmandu Momo Ghar logo",
      },
    ],
    siteName: "Newari Bhatti & Kathmandu Momo Ghar",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Newari Bhatti & Kathmandu Momo Ghar",
    description:
      "Authentic Newari dishes and momos in Kathmandu. Order online or visit our restaurant.",
    images: [`${SITE_URL}${LOGO_PATH}`],
  },
  // you can add icons: { icon: '/favicon.ico', apple: '/apple-touch-icon.png' } if desired
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning={true}>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
